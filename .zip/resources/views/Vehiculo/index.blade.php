@include('Plantillas.head')
<div class="bg-dark">
    <div class="container">
        @include('Plantillas.navbar')

  @include('Tablas.TablaV')

  @include('Plantillas.footer')
  
    </div>
</div>