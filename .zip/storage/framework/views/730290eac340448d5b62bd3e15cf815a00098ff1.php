<?php echo $__env->make('Plantillas.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Plantillas.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="w-100 row m-auto bg-dark mt-2 mb-2">
    
 <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="card m-auto mb-2 " style="width: 20rem;">
     <img src="<?php echo e(asset('storage').'/'.$vehi->foto); ?>" class="card-img-top h-50" alt="<?php echo e(asset('storage').'/'.$vehi->foto); ?>">
     <div class="card-body">
       <p class="card-header">ID: <?php echo e($vehi->idvehiculos); ?></p>
       <p class="card-header">MARCA: <?php echo e($vehi->marca); ?></p>
       <p class="card-header">MODELO: <?php echo e($vehi->modelo); ?></p>
       <p class="card-header">COLOR: <?php echo e($vehi->color); ?></p>
       <p class="card-header">DESTINO: <?php echo e($vehi->destino); ?></p>
       <p class="card-header">PLACAS: <?php echo e($vehi->placas); ?></p>
       <p class="card-header">TIPO: <?php echo e($vehi->tipo); ?></p>
       <p class="card-header">CAPASIDAD: <?php echo e($vehi->capasidad); ?></p>
       <p class="card-header">PRECIO: <?php echo e($vehi->precio); ?></p>
       <p class="card-header">ESTATUS: <?php echo e($vehi->estatus); ?></p>
     </div>
   </div>
   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\clienteCamionViaje\resources\views/publico/index.blade.php ENDPATH**/ ?>