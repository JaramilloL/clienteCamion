<a href="<?php echo e(url('auxiliar/create')); ?>" class="btn btn-secondary m-3">Crear Registro</a>

<table class="table">
    <thead>
      <tr class="text-white">
        <th scope="col">#</th>
        <th scope="col">Nombre</th> 
        <th scope="col">Apellido</th>
        <th scope="col">Status</th>
        <th scope="col">Sexo</th>
        <th scope="col">Foto</th>
        <th scope="col">acciones</th>
      </tr>
    </thead>

    <tbody>
     <?php $__currentLoopData = $auxiliares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aux): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr class="text-white">
       <td><?php echo e($aux->idAuxiliares); ?></td>
       <td><?php echo e($aux->nombre); ?></td>
       <td><?php echo e($aux->apellido); ?></td>
       <td><?php echo e($aux->status); ?></td>
       <td><?php echo e($aux->sexo); ?></td>

       <td class="w-auto">
         <img src="<?php echo e(asset('storage').'/'.$aux->foto); ?>" alt="" class="img-fluid" width="100px">
       </td>
       <td>
         <a href="<?php echo e(url('/auxiliar/'.$aux->idAuxiliares.'/edit')); ?>" class="btn btn-primary">Editar</a>
         | 
         
         <form action="<?php echo e(url('/auxiliar/'.$aux->idAuxiliares)); ?>" method="post">
           <?php echo csrf_field(); ?>
           <?php echo e(method_field('DELETE')); ?>


           <input 
               type="submit" 
               onclick="return confirm('quieres borrar este dato?')" value="Borrar" 
               class="btn btn-danger">
         </form>
       </td>
     </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
  </table><?php /**PATH C:\laragon\www\clienteCamionViaje\resources\views/Tablas/TablaA.blade.php ENDPATH**/ ?>