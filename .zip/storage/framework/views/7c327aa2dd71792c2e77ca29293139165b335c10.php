<?php echo $__env->make('Plantillas.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="bg-dark">
    <div class="container">
        <?php echo $__env->make('Plantillas.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('Tablas.TablaV', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('Plantillas.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    </div>
</div><?php /**PATH C:\laragon\www\clienteCamionViaje\resources\views/Vehiculo/index.blade.php ENDPATH**/ ?>